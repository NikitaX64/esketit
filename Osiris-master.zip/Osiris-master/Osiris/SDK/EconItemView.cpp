#include "EconItemView.h"
#include "../Memory.h"

void EconItemView::clearInventoryImageRGBA() noexcept
{
    memory->clearInventoryImageRGBA(this);
}
